import React, { useEffect, useState } from 'react';
import logo from './logo.svg';
import './App.css';

function App() {
  let [products, setProducts] = useState([]);
  useEffect(() => {
    fetch("https://fakestoreapi.com/products?limit=5")
      .then(response => response.json())
      .then(data => setProducts(data));
  }, [])
  return (
    <div className="App">
      {
        products.map(product => <h1 key={product.id}>{product.title}</h1>)
      }
    </div>
  );
}

export default App;
